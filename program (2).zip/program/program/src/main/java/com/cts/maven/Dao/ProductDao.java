/* Aparna */
package com.cts.maven.Dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.maven.model.Product;
@Service
public class ProductDao {
	
	@Autowired
	ProductDaojdbc prod;
    public int addProduct(Product product) {
		return prod.addProduct(product);
	}
    public  int updateProduct(Product product) {
		return prod.updateProduct(product);
	
	}
    public int deleteProduct(int prodId) {
		return prod.deleteProduct(prodId);
    	
	}
	public List getAllProduct(Product product) {
	
		return prod.getAllProduct(product);
	}
	public Product getById(int prodId) {
		return prod.getById(prodId);
	
	}
	
}
/* Aparna */
package com.cts.maven.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.maven.Dao.ProductDao;
import com.cts.maven.model.Product;

@RestController
public class TestController {
	
	    @Autowired
	    private ProductDao productDao;

	   /* @RequestMapping(value = "/product",method=RequestMethod.POST)
	    public ModelAndView Productinfo(@ModelAttribute("product") Product product)
	    {
			return null;
	     
	    }*/
	    @RequestMapping(value="/admin/product",method=RequestMethod.POST)//produces = "application/json")
		public ResponseEntity<Product> addProduct(@RequestBody Product product) {
			HttpHeaders headers = new HttpHeaders();
			if(product == null) {
				return new ResponseEntity<Product>(HttpStatus.BAD_REQUEST);
			}
			productDao.addProduct(product);		
	        headers.add("Product Object Created -",String.valueOf(product.getProdId()));
			return new ResponseEntity<Product>(product,headers,HttpStatus.CREATED);
		}
		
		//Get By ID
		@RequestMapping(value="/admin/getbyid/{prodId}",method=RequestMethod.GET)
		public ResponseEntity<Product> getById(@PathVariable("prodId") int prodId) {
			Product product = productDao.getById(prodId);
			if(product == null) {
				return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
			}

			return new ResponseEntity<Product>(product,HttpStatus.OK);
		}
		

		//Delete by ID
		@RequestMapping(value="/admin/delete/{prodId}",method = RequestMethod.DELETE)
		public ResponseEntity<Product> deleteProduct(@PathVariable("prodId") int prodId){
			HttpHeaders headers = new HttpHeaders();
			Product product = productDao.getById(prodId);
			if(product == null) {
				return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
			}
			productDao.deleteProduct(prodId);
			headers.add("Product Deleted - ", String.valueOf(prodId));
			return new ResponseEntity<Product>(product,headers,HttpStatus.NO_CONTENT);

		}
		

		//Update Product Details
		@RequestMapping(value="/admin/update/{prodId}", method = RequestMethod.PUT)
		public ResponseEntity<Product> updateProduct(@PathVariable("prodId") int prodId, @RequestBody Product product){
			HttpHeaders headers = new HttpHeaders();
			Product isProduct = productDao.getById(prodId);
			if(isProduct == null) {
				return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
			}
			else if (product == null) {
				return new ResponseEntity<Product>(HttpStatus.BAD_REQUEST);
			}
			//productDao.updateProduct(product);
			headers.add("Product Updated - ", String.valueOf(prodId));
			return new ResponseEntity<Product>(product,headers,HttpStatus.OK);
		}

}


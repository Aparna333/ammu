package com.ecommerce.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.model.Buyer;
import com.ecommerce.repository.AddressRepository;
import com.ecommerce.repository.BuyerRepository;

@Service
public class BuyerService {
	
	@Autowired
	private BuyerRepository buyerRepository;
	
	@Autowired
	private AddressRepository addressRepository;
	
	
	public List<Buyer> getAllBuyer() {
		return buyerRepository.findAll();
	}
	
	public Buyer createBuyer(Buyer buyer) {
		addressRepository.save(buyer.getAddress());
		return buyerRepository.save(buyer);
	}
	
	public Buyer updateBuyer(Buyer buyer) {
		Optional<Buyer> existingBuyer = buyerRepository.findById(buyer.getBuyerId());
		Buyer newBuyer = null;
		if(existingBuyer.isPresent()) {
			newBuyer = existingBuyer.get();
			newBuyer.setUsername(buyer.getUsername());
			newBuyer.setPassword(buyer.getPassword());
			newBuyer.setEmailId(buyer.getEmailId());
			newBuyer.setMobileNumber(buyer.getMobileNumber());
			newBuyer = buyerRepository.save(newBuyer);
		}
		
		return newBuyer;
	}
	
	public Optional<Buyer> getBuyerById(Integer buyerId) {
		return buyerRepository.findById(buyerId);
	}
	

}

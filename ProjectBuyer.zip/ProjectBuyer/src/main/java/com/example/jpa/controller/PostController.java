package com.example.jpa.controller;

import com.example.jpa.exception.ResourceNotFoundException;
import com.example.jpa.model.Buyer;
import com.example.jpa.repository.PostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
public class PostController {

    @Autowired
    private PostRepository postRepository;

    @GetMapping("/post")
    public Page<Buyer> getAllPosts(Pageable pageable) {
        return postRepository.findAll(pageable);
    }

    @PostMapping("/posts")
    public Buyer createPost(@Valid @RequestBody Buyer post) {
        return postRepository.save(post);
    }

    @PutMapping("/posts/{buyerId}")
    public Buyer updatePost(@PathVariable Long buyerId, @Valid @RequestBody Buyer postRequest) {
        return postRepository.findById(buyerId).map(post -> {
            post.setUserName(postRequest.getUserName());
            post.setPassword(postRequest.getPassword());
            post.setEmail(postRequest.getEmail());
            post.setMobileNumber(postRequest.getMobileNumber());
            return postRepository.save(post);
        }).orElseThrow(() -> new ResourceNotFoundException("Id " + buyerId + " not found"));
    }


    @DeleteMapping("/posts/{buyerId}")
    public ResponseEntity<?> deletePost(@PathVariable Long buyerId) {
        return postRepository.findById(buyerId).map(post -> {
            postRepository.delete(post);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceNotFoundException("Id " + buyerId + " not found"));
    }

}

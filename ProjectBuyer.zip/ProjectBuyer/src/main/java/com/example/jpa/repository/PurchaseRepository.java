package com.example.jpa.repository;

import com.example.jpa.model.PurchaseHistory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PurchaseRepository extends JpaRepository<PurchaseHistory, Long> {
    Page<PurchaseHistory> findByPostId(Long postId, Pageable pageable);
    Optional<PurchaseHistory> findByIdAndPostId(Long id, Long postId);
}

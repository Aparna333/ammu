package com.example.jpa.controller;

import com.example.jpa.model.Buyer;
import com.example.jpa.service.BuyerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
public class BuyerController {

    @Autowired
    private BuyerService service;

    @GetMapping("/post")
    public Page<Buyer> getAllPosts(Pageable pageable) {
        return service.findAll(pageable);
    }

    @PostMapping("/posts")
    public Buyer createPost(@Valid @RequestBody Buyer post) {
        return service.save(post);
    }

    @PutMapping("/posts/{buyerId}")
    public Buyer updatePost(@PathVariable Buyer buyerId, @Valid @RequestBody Buyer postRequest) {
        return service.updateById(buyerId);
    }
}

package com.example.jpa.repository;

import com.example.jpa.model.Cart;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CartRepository extends JpaRepository<Cart, Long> {
    
	ResponseEntity<?> findAllById(Long buyerId, Long cartId);

	Page<Cart> findByIdAndPostId(Long commentId, Long postId);
}

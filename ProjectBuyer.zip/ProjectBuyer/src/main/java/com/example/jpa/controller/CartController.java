package com.example.jpa.controller;

import com.example.jpa.model.Buyer;
import com.example.jpa.model.Cart;
import com.example.jpa.service.BuyerService;
import com.example.jpa.service.CartService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

import javax.validation.Valid;

@RestController
public class CartController {

    @Autowired
    private CartService commentRepository;

    @Autowired
    private BuyerService postRepository;

    @PostMapping("/buyers/{buyerId}/cart")
    public Optional<Buyer> addCartItem(@PathVariable (value = "buyerId") Long buyerId,
                                 @Valid @RequestBody Cart cart) {
        return postRepository.findById(buyerId);
            
    }

    @PutMapping("/buyers/{buyerId}/cart/{cartId}")
    public Cart updateCartItem(@PathVariable (value = "buyerId") Long buyerId,
                                 @PathVariable (value = "cartId") Long cartId,
                                 @Valid @RequestBody Cart cart) {
        return commentRepository.updateCartItem(buyerId,cartId,cart);
    }
}

package com.example.jpa.service;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.example.jpa.model.Buyer;
import com.example.jpa.model.Cart;
import com.example.jpa.repository.BuyerRepository;

@Service
public class BuyerService {

	@Autowired
	private BuyerRepository buyerRepository;


	public Page<Buyer> findAll(Pageable pageable) {

		return buyerRepository.findAll(pageable);
	}

	public Buyer save(@Valid Buyer post) {

		return buyerRepository.save(post);
	}

	public Buyer updateById(Buyer buyerId) {
		Optional<Buyer> buyer1 = buyerRepository.findById(buyerId.getId());
		Buyer b=null;
		if(buyer1.isPresent()) {
			b = buyer1.get();
			b.setUserName(buyerId.getUserName());
			b.setPassword(buyerId.getPassword());
			b.setEmail(buyerId.getEmail());
			b.setMobileNumber(buyerId.getMobileNumber());
			b = buyerRepository.save(b);
		}
		return b;
	}

	public Optional<Buyer> findById(Long buyerId) {
		
		return buyerRepository.findById(buyerId);
	}

}

package com.example.jpa.service;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.jpa.exception.ResourceNotFoundException;
import com.example.jpa.model.Buyer;
import com.example.jpa.model.Cart;
import com.example.jpa.repository.BuyerRepository;
import com.example.jpa.repository.CartRepository;

@Service
public class CartService {

	@Autowired
	private CartRepository cartRepository;

	@Autowired
	private BuyerRepository buyerRepository;

	public Cart addCartItem(@PathVariable (value = "buyerId") Long buyerId,
			@PathVariable (value = "itemId") Long itemId,
			@Valid @RequestBody Cart cart) {
		Optional<Cart> buyer=cartRepository.findById(buyerId);
		return buyer.get();
		//return buyerRepo.findById(buyerId,itemId);
	}

	public Cart updateCartItem(Long buyerId, Long cartId, @Valid Cart cartRequest) {
		if(!buyerRepository.existsById(buyerId)) {
			throw new ResourceNotFoundException("BuyerId " + buyerId + " not found");
		}
		return cartRepository.findById(cartId).map(cart -> {
			cart.setItemId(cartRequest.getItemId());
			cart.setText(cartRequest.getText());
			return cartRepository.save(cart);
		}).orElseThrow(() -> new ResourceNotFoundException("CartId " + cartId + "not found"));
	}
}

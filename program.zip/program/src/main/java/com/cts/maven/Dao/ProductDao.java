package com.cts.maven.Dao;

import java.util.List;

import com.cts.maven.model.Product;

public class ProductDao {
	
    public int addProduct(Product product) {
		return 0;
		
	}
    public  int updateProduct(int prodId) {
		return prodId;
	
	}
    public int deleteProduct(int prodId) {
		return prodId;
    	
	}
	public List getAllProduct(Product product) {
	
		return null;
	}
	public int getbyId(int prodId) {
		return prodId;
	
	}
	
}
package com.cts.maven.Dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.cts.maven.model.Product;
@Repository
public class ProductDaojdbc extends ProductDao{
	@Autowired
	private DataSource ds;
	private JdbcTemplate jdbc;
	
	public ProductDaojdbc(DataSource dataSource) {
		JdbcTemplate jdbc=new JdbcTemplate(dataSource);
	}
	public void setJdbc(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}
	
	public int addProduct(Product product) {
		int storedStatus=jdbc.update("INSERT INTO product values(?,?,?,?)",new Object[] 
				{product.getProdId(),product.getProdName(),product.getQuantity(),product.getPrice()});
		System.out.println(storedStatus);
		return product.getProdId();
	}
	
	public int getbyId(int prodId) {
		String sql = "SELECT * FROM product WHERE prod_id=?";
		Product product = (Product)jdbc.queryForObject(sql, new Object[] {prodId},
				                                        new RowMapper<Product>() {
			@Override
			public Product mapRow(ResultSet rs, int rowNum) throws SQLException {

				Product product = new Product();

				product.setProdId(rs.getInt(1));
				product.setProdName(rs.getString(2));
				product.setQuantity(rs.getInt(3));
				product.setPrice(rs.getFloat(4));

				return product;
			}
	    }); return getbyId(prodId);
	}
	public int updateProduct(int prodId) {
		
		return updateProduct(prodId);
	}
	public int deleteProduct(int prodId) {
		String sql = "DELETE FROM contact WHERE contact_id=?";
	    jdbc.update(sql, prodId);
		return getbyId(prodId);
	}
	
	public List<Product> getAllProduct(Product product) {
		
		return getAllProduct(product);
	}
}


package com.cts.maven.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cts.maven.Dao.ProductDao;
import com.cts.maven.model.Product;

@RestController
public class TestController {
	
	 @Autowired
	    private ProductDao productDao;

	    @RequestMapping(value = "/product",method=RequestMethod.POST)
	    public ModelAndView Productinfo(@ModelAttribute("product") Product product)
	    {
			return null;
	     
	    }

}


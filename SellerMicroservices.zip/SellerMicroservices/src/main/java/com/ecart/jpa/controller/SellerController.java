package com.ecart.jpa.controller;

import com.ecart.jpa.entity.Seller;
import com.ecart.jpa.service.SellerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
public class SellerController {

    @Autowired
    private SellerService service;

    @GetMapping("/seller")
    public Page<Seller> getAllPosts(Pageable pageable) {
        return service.findAll(pageable);
    }

    @PostMapping("/seller")
    public Seller createSeller(@Valid @RequestBody Seller seller) {
        return service.save(seller);
    }
}

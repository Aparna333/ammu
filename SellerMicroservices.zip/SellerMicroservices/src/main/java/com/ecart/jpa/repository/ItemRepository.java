package com.ecart.jpa.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ecart.jpa.entity.Items;
import com.ecart.jpa.entity.Seller;

@Repository
public interface ItemRepository extends JpaRepository<Items, Long>{

	Object save(Long sellerId);
    
	//Optional<Seller> findByIdAndPostId(Long sellerId, Long itemId);

}

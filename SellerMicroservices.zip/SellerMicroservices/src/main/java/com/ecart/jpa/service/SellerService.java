package com.ecart.jpa.service;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.ecart.jpa.entity.Seller;
import com.ecart.jpa.repository.SellerRepository;

@Service
public class SellerService {
	
	@Autowired
	private SellerRepository sellerRepository;

	public Page<Seller> findAll(Pageable pageable) {
		
		return sellerRepository.findAll(pageable);
	}

	public Seller save(@Valid Seller seller) {
		
		return sellerRepository.save(seller);
	}

}

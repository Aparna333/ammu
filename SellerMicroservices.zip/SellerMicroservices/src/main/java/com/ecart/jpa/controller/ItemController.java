package com.ecart.jpa.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ecart.jpa.entity.Items;
import com.ecart.jpa.service.ItemService;
import com.ecart.jpa.service.SellerService;

@RestController
public class ItemController {
     
	@Autowired
	private ItemService service;
	
	@PostMapping(name = "/seller/{sellerId}/items", produces = "application/json")
    public Items addItem(@PathVariable (value = "sellerId") Long sellerId,
                                 @Valid @RequestBody Items item) {
     return service.addItem(sellerId, item);
    }
  
	@PutMapping("/sellers/{sellerId}/items/{itemId}")
    public Items updateItem(@PathVariable (value = "sellerId") Long sellerId,
                                 @PathVariable (value = "itemId") Long itemId,
                                 @Valid @RequestBody Items items) {
       return service.updateItem(sellerId, itemId, items);
    }
	/* @DeleteMapping("/posts/{postId}/comments/{commentId}")
	    public ResponseEntity<?> deleteItem(@PathVariable (value = "sellerId") Long sellerId,
	                              @PathVariable (value = "itemId") Long itemId) {
	        return service.findByIdAndPostId(itemId, sellerId);
	    }*/
}
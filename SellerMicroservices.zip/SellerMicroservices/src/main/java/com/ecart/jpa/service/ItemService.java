package com.ecart.jpa.service;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.ecart.jpa.entity.Items;
import com.ecart.jpa.repository.ItemRepository;
import com.ecart.jpa.repository.SellerRepository;
import com.ecart.jpa.exception.ResourceNotFoundException;

@Service
public class ItemService {
	@Autowired
	private ItemRepository itemRepository;

	@Autowired
	private SellerRepository sellerRepository;

	public Items addItem(@PathVariable (value = "sellerId") Long sellerId,
			             @Valid @RequestBody Items item) {
		return sellerRepository.findById(sellerId).map(seller -> {
			item.setSeller(seller);
			return itemRepository.save(item);
		}).orElseThrow(() -> new ResourceNotFoundException("sellerId " + sellerId + " not found"));
	}

	public Items updateItem(@PathVariable (value = "sellerId") Long sellerId,
			                @PathVariable (value = "itemId") Long itemId,
			                @Valid @RequestBody Items items) {
		if(!sellerRepository.existsById(sellerId)) {
			throw new ResourceNotFoundException("SellerId " + sellerId + " not found");
		}

		return itemRepository.findById(itemId).map(item -> {
			item.setCategoryId(items.getCategoryId());
			item.setSubCategoryId(items.getSubCategoryId());
			item.setItemName(items.getItemName());
			item.setPrice(items.getPrice());
			item.setStockNumber(items.getStockNumber());
			item.setDescription(items.getDescription());
			item.setRemarks(items.getRemarks());
			return itemRepository.save(item);
		}).orElseThrow(() -> new ResourceNotFoundException("ItemId " + itemId + "not found"));
	}

	/*public ResponseEntity<?> deleteItem(@PathVariable (value = "sellerId") Long sellerId,
			@PathVariable (value = "itemId") Long itemId) {
		return itemRepository.findByIdAndPostId(sellerId, itemId).map(item -> {
			itemRepository.delete(item);
			return ResponseEntity.ok().build();
		}).orElseThrow(() -> new ResourceNotFoundException("Comment not found with id " + itemId + " and postId " + sellerId));
	}
}*/

}
